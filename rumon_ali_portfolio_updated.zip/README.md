# Md. Rumon Ali — Personal Portfolio

A responsive personal portfolio website for showcasing my background, skills, projects, and experience in Data Analytics and AI Data Annotation.

## How to use
1. Upload `index.html` to a GitHub repository.
2. Email: rumonali3222@gmail.com
3. GitHub: https://github.com/rumon1234-lab/MD.RUMON-ALI
4. Replace the `RA` initials with your profile photo if desired.
5. Update project links and add dashboard screenshots.

## Publish with GitHub Pages
1. Open the repository on GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**, then Save.
5. Wait for GitHub Pages to publish the site.

## Files
- `index.html` — complete responsive portfolio website.

LinkedIn: https://linkedin.com/in/md-rumon-ali
